export const environment = {
  production: true,
 // api: "http://10.28.140.166:8080/memberOptions",
  //loginapiUrl: 'http://localhost:9997'
  //loginapiUrl: 'http://10.28.140.166:8080/loginService'
   api: "http://localhost:9091/memberOptions",
 //loginapiUrl: 'http://localhost:9080/loginService'
};
