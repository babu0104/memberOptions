export class UserService {
    public icaBin: string;
    public existingBin: string;
    public assocFlag: string;
    public mso: string;
    public existingMso: string;
    public effectiveDate: string;
    public thresoldOption: string;
    public retroDelivery: string;
    public retroSSNVelo: string;
    public retroSSNUnauthUse: string;
    public retroPhoneVelo: string;
    public retroPhoneUnauthUse: string;
    public retroAddrVelo: string;
    public retroAddrUnauthUse: string;
    public bankruptcyRetros: string;
    public retroVelocityTimeFrame: string;
    public retroUnauthUseTimeFrame: string;
    public retroBankruptcyTimeframe: string;
    public bankruptcyAlertTimeframe: string;
    public nonBankcardMSO: string;
    public loadTS: string;
    public lastUpdatedUserId: string;

    constructor() { }
}

