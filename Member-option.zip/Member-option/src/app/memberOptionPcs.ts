export class Pcs {
    public pcsbin: string;
    public pcsmso: string;
    constructor() { }

}
