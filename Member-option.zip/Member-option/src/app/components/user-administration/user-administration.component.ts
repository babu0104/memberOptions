import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-administration',
  templateUrl: './user-administration.component.html',
  styleUrls: ['./user-administration.component.scss']
})
export class UserAdministrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
