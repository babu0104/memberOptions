import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ics-settings',
  templateUrl: './ics-settings.component.html',
  styleUrls: ['./ics-settings.component.scss']
})
export class IcsSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
