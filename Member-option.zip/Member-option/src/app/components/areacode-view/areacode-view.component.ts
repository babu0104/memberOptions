import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-areacode-view',
  templateUrl: './areacode-view.component.html',
  styleUrls: ['./areacode-view.component.scss']
})
export class AreacodeViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
