import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scf-view',
  templateUrl: './scf-view.component.html',
  styleUrls: ['./scf-view.component.scss']
})
export class ScfViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
