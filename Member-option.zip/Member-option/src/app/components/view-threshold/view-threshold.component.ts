import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-view-threshold',
    templateUrl: './view-threshold.component.html',
    styleUrls: ['./view-threshold.component.scss']
})
export class ViewThresholdComponent implements OnInit {
    constructor() { }
    ngOnInit() { }
}

