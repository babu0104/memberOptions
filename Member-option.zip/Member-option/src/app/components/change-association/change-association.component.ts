import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-association',
  templateUrl: './change-association.component.html',
  styleUrls: ['./change-association.component.scss']
})
export class ChangeAssociationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
