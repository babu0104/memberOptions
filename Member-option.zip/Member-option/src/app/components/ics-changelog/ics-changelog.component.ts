import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ics-changelog',
  templateUrl: './ics-changelog.component.html',
  styleUrls: ['./ics-changelog.component.scss']
})
export class IcsChangelogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
