import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-retro-threshold',
  templateUrl: './view-retro-threshold.component.html',
  styleUrls: ['./view-retro-threshold.component.scss']
})
export class ViewRetroThresholdComponent implements OnInit {
  extended:any;
    constructor() { }
    ngOnInit() { }
 }

