import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescreen-view',
  templateUrl: './prescreen-view.component.html',
  styleUrls: ['./prescreen-view.component.scss']
})
export class PrescreenViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
