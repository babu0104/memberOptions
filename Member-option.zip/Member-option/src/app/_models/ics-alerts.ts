export class User {
    public bin: string;
    public mso: string;
    public assoFlag: string;
    public ssnAlerts: string;
    public ssnInvalids: string;
    public addrAlerts: string;
    public addrInvalids: string;
    public phoneAlerts: string;
    public phoneInvalids: string;
    public nonBankCard: string;
    constructor() { }

}
