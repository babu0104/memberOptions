export class IcsMemberBinBidAssocDto {
    businessId?: string;
    bin?: string;
    loadTs?: null;
    procId?: string;
    extractTs?: number;
    binModified?: boolean;
    lastModifiedOn?: string;
    lastUpdtUserId?: string;

    constructor() { }
}
