export class IntMemberTblDto {
    icsBin?: string;
    assocFlag?: string;
    boName?: string;
    boPhone?: string;
    boFax?: string;
    boEmail?: string;
    tcName?: string;
    tcPhone?: string;
    tcFax?: string;
    tcEmail?: string;
    pmBoName?: string;
    pmBoPhone?: string;
    pmBoFax?: string;
    pmBoEmail?: string;
    pmTcName?: string;
    pmTcPhone?: string;
    pmTcFax?: string;
    pmTcEmail?: string;
    binModified?: boolean;
    lastModifiedOn?: string;
    loadTs?: null;
    lastUpdatedUId?: string;
    binModifiedDate?: string;

    constructor() { }
}
