export class IntMemberIcsDirectTblDto {
    businessId?: string;
    loadTs?: null;
    mbrName?: string;
    mbrAddr1?: string;
    mbrAddr2?: string;
    mbrCity?: string;
    mbrState?: string;
    mbrZipCode?: string;
    extractTs?: null;
    bidModified?: boolean;
    lastModifiedOn?: string;
    lastUpdtUserId?: string;
    bidModifiedDate?: string;
    constructor() {

    }
}
