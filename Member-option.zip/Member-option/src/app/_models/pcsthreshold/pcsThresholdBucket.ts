export class pcsThresholdBucket {
    uuDeCode ?: string;
    bucket ?: number;
    applVelocityHigh ?: string ;
    appVelocityLow ?: string ;
    appVelocityThreshold ?: string ;
    appVelocityThresholdAmt ?: string ;


    constructor () {}
}

