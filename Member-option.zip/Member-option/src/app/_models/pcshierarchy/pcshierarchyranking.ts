export class PcsHierarchyRanking {
    hierarchyCode: string;
    vaisResponseCode: string;
    description: string;
    constructor() {
    }
}
