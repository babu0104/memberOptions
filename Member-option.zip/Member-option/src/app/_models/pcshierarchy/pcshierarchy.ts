import { PcsHierarchyRanking } from './pcshierarchyranking';
export class PcsHierarchy {
    icaBin: string;
    mso: string;
    system:string;
    inputRecordType: string;
    pcsHierarchyRankingDto: Array<PcsHierarchyRanking>;
    loadTS: string;
    lastUpdatedUserId: string;
    constructor() {

    }
}
