export class listThresholdDataNode {
    uuDeCode?: string;
    bucket?: string;
    highDay?: string;
    lowDay?: string;
    thresholdValue?: string;
    loadTS?: string;

    constructor() { }
}

export class listRetroThresholdDataNode {
    uuDeCode?: string;
    bucket?: string;
    applVelocityHigh?: string;
    applVelocityLow?: string;
    thresholdValue?: string;
    loadTS?: string;

    constructor() { }
}
