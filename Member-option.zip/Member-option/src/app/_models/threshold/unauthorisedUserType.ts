export class UnauthorisedUserType {
    period1Low = 1;
    period1High = 90;
    period1Ssn: number;
    period1Address: number;
    period1Phone: number;
    period1LoadTS: number;

    period2Low = 1;
    period2High = 365;
    period2Ssn: number;
    period2Address: number;
    period2Phone: number;
    period2LoadTS: number;

    period3Low = 1;
    period3High: number;
    period3Ssn: number;
    period3Address: number;
    period3Phone: number;
    period3LoadTS: number;

    period4Low = 1;
    period4High: number;
    period4Ssn: number;
    period4Address: number;
    period4Phone: number;
    period4LoadTS: number;

    public clear() {
        // this.period1Low = null;
        // this.period1High = null;
        this.period1Ssn = null;
        this.period1Address = null;
        this.period1Phone = null;
        this.period1LoadTS = null;

        // this.period2Low = null;
        // this.period2High = null;
        this.period2Ssn = null;
        this.period2Address = null;
        this.period2Phone = null;
        this.period2LoadTS = null;

        // this.period3Low = null;
        // this.period3High = null;
        this.period3Ssn = null;
        this.period3Address = null;
        this.period3Phone = null;
        this.period3LoadTS = null;

        // this.period4Low = null;
        // this.period4High = null;
        this.period4Ssn = null;
        this.period4Address = null;
        this.period4Phone = null;
        this.period4LoadTS = null;
    }

    constructor() { }
}

export class UnauthorisedUserType00 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType01 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType02 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType03 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType04 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType05 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType06 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType07 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType08 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}

export class UnauthorisedUserType09 extends UnauthorisedUserType {
    constructor() {
        super();
    }
}
