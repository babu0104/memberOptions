export class Threshold {
    bin: string;
    mso: string;
    nonBankcard: string;
    assocFlag: string;
    lastUpdatedUserId: string;
    name: string;
    address: string;
}
