export class UuType {
    uuDeCode: string;
    bucket: number;
    highDay: number;
    lowDay: number;
    applVelocityHigh: number;
    applVelocityLow: number;
    thresholdValue: number;
    loadTS: number;

    constructor () {}
}
