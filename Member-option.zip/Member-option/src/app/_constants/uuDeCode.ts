export class UuDeCode {
    public static ssn = 'DESSN';
    public static adr = 'DEADR';
    public static phn = 'DEPHN';

    public static uus00 = 'UUS00';
    public static uus01 = 'UUS01';
    public static uus02 = 'UUS02';
    public static uus03 = 'UUS03';
    public static uus04 = 'UUS04';
    public static uus05 = 'UUS05';
    public static uus06 = 'UUS06';
    public static uus07 = 'UUS07';
    public static uus08 = 'UUS08';
    public static uus09 = 'UUS09';

    public static uua00 = 'UUA00';
    public static uua01 = 'UUA01';
    public static uua02 = 'UUA02';
    public static uua03 = 'UUA03';
    public static uua04 = 'UUA04';
    public static uua05 = 'UUA05';
    public static uua06 = 'UUA06';
    public static uua07 = 'UUA07';
    public static uua08 = 'UUA08';
    public static uua09 = 'UUA09';

    public static uup00 = 'UUP00';
    public static uup01 = 'UUP01';
    public static uup02 = 'UUP02';
    public static uup03 = 'UUP03';
    public static uup04 = 'UUP04';
    public static uup05 = 'UUP05';
    public static uup06 = 'UUP06';
    public static uup07 = 'UUP07';
    public static uup08 = 'UUP08';
    public static uup09 = 'UUP09';
}
