export interface Hierarchy {
    code;
    description;
}
